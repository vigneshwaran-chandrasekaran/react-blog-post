import React, { useEffect } from 'react';

export default function EditBlogPost() {

    useEffect(() => {
        // get particular dat
    }, []);

    return (
        <div>
            EditBlogPost
        </div>
    )
}
